#-####################################################################-#
#----------------------------# 0. IMPORTS #----------------------------#
import cv2
from flask import render_template, request
from brainmri import app
import glob
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
import os
import pandas as pd
import scipy.misc as sc
from scipy import ndimage
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import *
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import ImageDataGenerator

#-####################################################################-#
#----------------------------# 1. CONFIGS #----------------------------#
#-i. CONSTANTS
HOUNSFIELD_MIN = 0
HOUNSFIELD_MAX = 500
HOUNSFIELD_RANGE = HOUNSFIELD_MAX - HOUNSFIELD_MIN


SLICE_X = False
SLICE_Y = False
SLICE_Z = True

IMAGE_HEIGHT = 256
IMAGE_WIDTH = 176
IMG_SIZE = (IMAGE_HEIGHT, IMAGE_WIDTH)

#-ii. UDF'S
def normalizeImage(img):
    return (img)/255

def scaleImg(img, height, width):
    return cv2.resize(
          img
        , dsize=(width, height)
        , interpolation=cv2.INTER_LINEAR)

def predictVolume(inImg, model, toBin=True):
    (xMax, yMax, zMax) = inImg.shape
    
    outImgX = np.zeros((xMax, yMax, zMax))
    outImgY = np.zeros((xMax, yMax, zMax))
    outImgZ = np.zeros((xMax, yMax, zMax))
    
    cnt = 0.0
    if SLICE_X:
        cnt += 1.0
        for i in range(xMax):
            img = scaleImg(
                  inImg[i,:,:]
                , IMAGE_HEIGHT
                , IMAGE_WIDTH)[np.newaxis,:,:,np.newaxis]
            tmp = model.predict(img)[0,:,:,0]
            outImgX[i,:,:] = scaleImg(tmp, yMax, zMax)
    if SLICE_Y:
        cnt += 1.0
        for i in range(yMax):
            img = scaleImg(
                  inImg[:,i,:]
                , IMAGE_HEIGHT
                , IMAGE_WIDTH)[np.newaxis,:,:,np.newaxis]
            tmp = model.predict(img)[0,:,:,0]
            outImgY[:,i,:] = scaleImg(tmp, xMax, zMax)
    if SLICE_Z:
        cnt += 1.0
        for i in range(zMax):
            img = scaleImg(
                  inImg[:,:,i]
                , IMAGE_HEIGHT
                , IMAGE_WIDTH)[np.newaxis,:,:,np.newaxis]
            tmp = model.predict(img)[0,:,:,0]
            outImgZ[:,:,i] = scaleImg(tmp, xMax, yMax)
            
    outImg = (outImgX + outImgY + outImgZ)/cnt
    if(toBin):
        outImg[outImg>0.5] = 1.0
        outImg[outImg<=0.5] = 0.0
    return outImg

def process_scan(img_data):
    img_data = img_data[:, :, 0:249]
    
    #-00. NORMALIZE - Z-SCORE
    mask_data = img_data > img_data.mean()
    logical_mask = mask_data > 0.  # forcing the mask to be logical type
    mean = img_data[logical_mask].mean()
    std = img_data[logical_mask].std()
    norm_value = (img_data - mean) / std
    img = norm_value.astype("float32")
    
    #-01. RESIZE - Setting the desired depth
    desired_depth =250
    desired_width =170
    desired_height =250
    
    #-02. Get current depth
    current_depth = img.shape[-1]
    current_width = img.shape[0]
    current_height = img.shape[1]
    
    #-03. Compute depth factor
    depth = current_depth / desired_depth
    width = current_width / desired_width
    height = current_height / desired_height
    depth_factor = 1 / depth
    width_factor = 1 / width
    height_factor = 1 / height
    
    #-04. Resize across z-axis
    img = ndimage.zoom(
          img
        , (width_factor, height_factor, depth_factor)
        , order=1)
    return img

#-####################################################################-#
#-----------------------------# 2. HOME #------------------------------#
@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html',
                           title='Home')

#-####################################################################-#
#-----------------------------# 3. INPUT #-----------------------------#
@app.route('/input')
def input():
    return render_template('data_in.html',
                           title='MRI-Analysis')

#-####################################################################-#
#----------------------------# 4. OUTPUT #-----------------------------#
@app.route('/output', methods=['GET', 'POST'])
def output():
    #-01. Input Data
    if request.method == 'POST':
        cur_inq = str(len(
            os.listdir(
                  os.path.join(os.getcwd()
                , "brainmri/inquiries/"))))+".nii.gz"
        request.files['data'].save(
              os.path.join(os.getcwd(), "brainmri/inquiries/", cur_inq))
        
    input_img = nib.load(
        os.path.join(
            os.getcwd(), "brainmri/inquiries/", cur_inq)).get_fdata()
    norm_img = normalizeImage(input_img)

    #-01. UNET SEGMENTATION & PRE-PROCESSING
    unet_seg_model = load_model(
    os.path.join(
          os.getcwd(), "brainmri/static/", 'unet_brain-segmentation.h5'))
    seg_img = predictVolume(norm_img, model=unet_seg_model)
    seg_img_greyscale = seg_img*norm_img
    seg_img_final = process_scan(seg_img_greyscale)
    
    #-02. 3D-CNN BINARY CLASSIFIER
    cnn_model = load_model(
    os.path.join(
          os.getcwd(), "brainmri/static/", '3dcnn_binary_classifier.h5'))
    ad_prob = cnn_model.predict(np.expand_dims(seg_img_final, axis=0))[0][0]
    if ad_prob > 0.5:
        bi_class = "Alzheimer's Disease"
    else:
        bi_class = "normal"
    return render_template(
      'results_out.html'
    , title='Dementia Prediction'
    , bi_class = bi_class
    , ad_prob = float(round(ad_prob*100, 2))
    )

#-####################################################################-#
#---------------------------# 5. CONTACT #-----------------------------#
@app.route('/contact')
def contact():
    return render_template('contact.html',
                           title='Contact')

#-####################################################################-#
#-----------------------------# 6. ABOUT #-----------------------------#
@app.route('/about')
def about():
    return render_template('about.html',
                           title='About')
